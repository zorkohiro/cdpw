This file shows how to create a simple Web service in C++ (similar to
Python's Flask) using the Orthanc standalone framework.
