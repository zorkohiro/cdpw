/**
 * Orthanc - A Lightweight, RESTful DICOM Store
 * Copyright (C) 2012-2016 Sebastien Jodogne, Medical Physics
 * Department, University Hospital of Liege, Belgium
 * Copyright (C) 2017-2023 Osimis S.A., Belgium
 * Copyright (C) 2024-2024 Orthanc Team SRL, Belgium
 * Copyright (C) 2021-2024 Sebastien Jodogne, ICTEAM UCLouvain, Belgium
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program. If not, see
 * <http://www.gnu.org/licenses/>.
 **/


#pragma once

#include "IJob.h"
#include "Operations/IJobOperationValue.h"
#include "Operations/IJobOperation.h"

#include <vector>

namespace Orthanc
{
  class ORTHANC_PUBLIC IJobUnserializer : public boost::noncopyable
  {
  public:
    virtual ~IJobUnserializer()
    {
    }

    virtual IJob* UnserializeJob(const Json::Value& value) = 0;

    virtual IJobOperation* UnserializeOperation(const Json::Value& value) = 0;

    virtual IJobOperationValue* UnserializeValue(const Json::Value& value) = 0;
  };
}
