#ifndef BLOCK_LIST_H
# define BLOCK_LIST_H

# include "fsmap.h"

extern struct fsmap_format block_list_format;

#endif /* !BLOCK_LIST_H */
